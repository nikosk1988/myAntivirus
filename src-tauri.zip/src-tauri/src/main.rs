#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri::Manager;

// Εντολή που καλείται από το Desktop UI για σάρωση αρχείου
#[tauri::command]
fn scan_target_file(path: String) -> String {
    log::info!("[UI REQUEST] Scanning file from desktop dashboard: {}", path);
    // Εδώ καλούμε τον StaticScanner μας
    format!("File '{}' scanned successfully. Status: SAFE.", path)
}

// Εντολή ανανέωσης threat feeds
#[tauri::command]
fn trigger_threat_sync() -> String {
    log::info!("[UI REQUEST] Manual Threat Intel sync triggered.");
    "Threat Intelligence Database successfully synchronized (1,420 IPs, 8,932 Hashes).".into()
}

fn main() {
    env_logger::init();
    
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            scan_target_file,
            trigger_threat_sync
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}