use notify::{Config, Event, EventKind, RecommendedWatcher, RecursiveMode, Watcher};
use std::path::Path;
use std::sync::mpsc::channel;
use std::time::{Duration, Instant};
use sysinfo::System;

pub struct BehavioralMonitor {
    watch_path: String,
}

impl BehavioralMonitor {
    pub fn new(watch_path: &str) -> Self {
        Self {
            watch_path: watch_path.to_string(),
        }
    }

    pub fn start_filesystem_guard(&self) -> notify::Result<()> {
        log::info!("[*] Advanced Filesystem Behavioral Guard ACTIVE on: {}", self.watch_path);

        let (tx, rx) = channel();
        let mut watcher = RecommendedWatcher::new(tx, Config::default())?;
        watcher.watch(Path::new(&self.watch_path), RecursiveMode::Recursive)?;

        let mut event_count = 0;
        let mut window_start = Instant::now();
        let threshold_count = 15; // 15 μαζικές τροποποιήσεις
        let threshold_window = Duration::from_secs(2); // σε διάστημα 2 δευτερολέπτων

        loop {
            match rx.recv() {
                Ok(Ok(event)) => {
                    if let EventKind::Modify(_) = event.kind {
                        let now = Instant::now();
                        
                        if now.duration_since(window_start) > threshold_window {
                            event_count = 0;
                            window_start = now;
                        }

                        event_count += 1;

                        if event_count > threshold_count {
                            log::error!(
                                "[RANSOMWARE HEURISTIC DETECTED] Rapid file modifications in {:?}",
                                event.paths
                            );

                            // Εντοπισμός και εξουδετέρωση της ύποπτης διεργασίας
                            self.neutralize_high_cpu_or_io_threats();
                        }
                    }
                }
                Ok(Err(e)) => log::error!("Watch error: {:?}", e),
                Err(e) => log::error!("Channel error: {:?}", e),
            }
        }
    }

    fn neutralize_high_cpu_or_io_threats(&self) {
        let mut sys = System::new_all();
        sys.refresh_all();

        // Εντοπισμός διεργασιών με ασυνήθιστα υψηλή χρήση CPU/IO κατά τη διάρκεια του συμβάντος
        for (pid, process) in sys.processes() {
            if process.cpu_usage() > 70.0 && process.name() != "shield_core" {
                log::warn!("[ACTIVE MITIGATION] Neutralizing high-activity threat PID: {} ({})", pid, process.name());
                process.kill();
            }
        }
    }
}