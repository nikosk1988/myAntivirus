use sysinfo::{Pid, System};
use std::collections::HashSet;

pub struct ProcessGuard {
    suspicious_parents: HashSet<String>,
    suspicious_children: HashSet<String>,
}

impl ProcessGuard {
    pub fn new() -> Self {
        let mut suspicious_parents = HashSet::new();
        // Εφαρμογές που ΔΕΝ πρέπει να εκτελούν interpreters/shells
        suspicious_parents.insert("winword.exe".to_string());
        suspicious_parents.insert("excel.exe".to_string());
        suspicious_parents.insert("firefox".to_string());
        suspicious_parents.insert("chrome".to_string());

        let mut suspicious_children = HashSet::new();
        suspicious_children.insert("cmd.exe".to_string());
        suspicious_children.insert("powershell.exe".to_string());
        suspicious_children.insert("bash".to_string());
        suspicious_children.insert("sh".to_string());

        Self {
            suspicious_parents,
            suspicious_children,
        }
    }

    /// Σάρωση του δέντρου διεργασιών για ανίχνευση ύποπτης σχέσης Parent-Child
    pub fn inspect_process_tree(&self, sys: &System, self_pid: Pid) {
        for (pid, process) in sys.processes() {
            // Μηχανισμός Anti-Tamper: Προστασία του δικού μας PID
            if *pid == self_pid {
                continue;
            }

            let process_name = process.name().to_lowercase();

            if let Some(parent_pid) = process.parent() {
                if let Some(parent_process) = sys.process(parent_pid) {
                    let parent_name = parent_process.name().to_lowercase();

                    // Έλεγχος αν ένας "ασφαλής" γονέας προσπαθεί να τρέξει ένα επικίνδυνο shell
                    if self.suspicious_parents.contains(&parent_name)
                        && self.suspicious_children.contains(&process_name)
                    {
                        log::warn!(
                            "[PROCESS LINEAGE ALARM] Suspicious execution detected! Parent: '{}' (PID: {}) spawned Child: '{}' (PID: {})",
                            parent_name, parent_pid, process_name, pid
                        );

                        // Ενέργεια: Άμεσος τερματισμός της κακόβουλης θυγατρικής διεργασίας
                        log::error!("[ANTI-TAMPER ACTION] Terminating untrusted spawned process PID: {}", pid);
                        process.kill();
                    }
                }
            }
        }
    }
}