use std::fs;
use std::path::{Path, PathBuf};
use std::io;
use chrono::Utc;

pub struct QuarantineManager {
    quarantine_dir: PathBuf,
}

impl QuarantineManager {
    pub fn new(base_path: &str) -> io::Result<Self> {
        let q_dir = Path::new(base_path).join("quarantine");
        if !q_dir.exists() {
            fs::create_dir_all(&q_dir)?;
        }
        Ok(Self { quarantine_dir: q_dir })
    }

    /// Μεταφορά αρχείου σε καραντίνα
    pub fn isolate_file<P: AsRef<Path>>(&self, file_path: P, reason: &str) -> io::Result<PathBuf> {
        let path = file_path.as_ref();
        if !path.exists() {
            return Err(io::Error::new(io::ErrorKind::NotFound, "File not found for quarantine"));
        }

        let file_name = path.file_name()
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "Invalid file name"))?;
        
        let timestamp = Utc::now().format("%Y%m%d_%H%M%S");
        let new_name = format!("{}_{}", timestamp, file_name.to_string_lossy());
        let destination = self.quarantine_dir.join(new_name);

        // Μετακίνηση αρχείου στην καραντίνα
        fs::rename(path, &destination)?;

        // Αφαίρεση δικαιωμάτων εγγραφής/εκτέλεσης (Lockdown)
        let mut perms = fs::metadata(&destination)?.permissions();
        perms.set_readonly(true);
        fs::set_permissions(&destination, perms)?;

        log::warn!("[QUARANTINE] File successfully isolated: {:?} -> {:?}", path, destination);
        log::warn!("[REASON] Threat detected: {}", reason);

        Ok(destination)
    }
}